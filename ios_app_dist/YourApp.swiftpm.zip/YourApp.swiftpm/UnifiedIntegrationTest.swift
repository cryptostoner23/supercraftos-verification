import SwiftUI
import Combine

struct UnifiedIntegrationTest: View {
    @StateObject private var client: UnifiedAPIClient
    @State private var status = "Not started"
    @State private var data: [String: Any] = [:]
    
    init(client: UnifiedAPIClient) {
        self.client = client
    }
    
    var body: some View {
        VStack {
            Text("Unified API Integration Test")
                .font(.headline)
                .padding()
            
            Text(status)
                .font(.title2)
                .padding()
            
            if !data.isEmpty {
                VStack(alignment: .leading) {
                    Text("Response:")
                        .font(.headline)
                    Text(data.description)
                        .font(.body)
                }
                .padding()
            }
            
            Button(action: testReasoning) {
                Text("Test Reasoning")
            }
        }
        .onAppear {
            Task {
                await runIntegrationTest()
            }
        }
    }
    
    func testReasoning() {
        Task {
            await runIntegrationTest()
        }
    }
    
    func runIntegrationTest() async {
        status = "Running..."
        do {
            // Test agent status
            let agentData = try await client.unifiedAgentStatus()
            data["agent_status"] = agentData
            status = "Agent status retrieved"
            
            // Test model routing
            let modelData = try await client.unifiedModelRoute(
                taskType: "reasoning", 
                complexity: "medium", 
                costSensitive: true
            )
            data["model_route"] = modelData
            status = "Model routing successful"
            
            // Test health
            let healthData = try await client.unifiedHealth()
            data["health"] = healthData
            status = "Health check successful"
            
        } catch {
            status = "Error: \(error.localizedDescription)"
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        UnifiedIntegrationTest(client: UnifiedAPIClient(connection: BackendConnection(address: "http://localhost:8790", accessKey: "test-key")))
    }
}
